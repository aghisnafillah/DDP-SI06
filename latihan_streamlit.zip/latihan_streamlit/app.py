import streamlit as st
# CSS to Streamlit

st.markdown(
    """
    <style>



    """
    unsafe_allow_html= True


)





# # st.title("Hallo kamu")
# # st.markdown("selamat datang di rumah coding")
# st.image("images.jpg", caption="ini gambar")

dashboard = st.Page("./fitur/dashboard.py", title="dashboard")
nabung = st.Page("./fitur/nabung.py", title="menabung")
penarikan = st.Page("./fitur/penarikan.py", title="penarikan")

pg = st.navigation(
    {
      "Menu utama" : [dashboard],
      "Tansaksi" : [nabung, penarikan]

    }
)

if 'total_semua' not in st.session_state:
    st.session_state['total_semua'] = []
pg.run()