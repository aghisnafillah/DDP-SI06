import streamlit as st

st.title("Halaman Penarikan")

# Formulir Input
with st.form("Penarikan"):
    nama = st.text_input("Nama")
    jumlah = st.number_input("jumlah (Rp.)", min_value=0, step=1000)
    tanggal = st.date_input("tanggal")
    waktu = st.time_input("waktu")
    submit_button = st.form_submit_button(label="Penarikan")

    if submit_button and jumlah >=50000: 
        st.session_state['total_semua'].append({
            'Tipe' : 'Penarikan', 
            'jumlah' : jumlah
        })
        st.success("Penarikan Berhasil")
    else:
        st.error("Penarikan gagal")
